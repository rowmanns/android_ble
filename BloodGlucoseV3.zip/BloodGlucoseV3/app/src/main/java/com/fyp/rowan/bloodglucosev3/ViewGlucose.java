package com.fyp.rowan.bloodglucosev3;

import android.app.Activity;
import android.os.Bundle;

public class ViewGlucose extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_glucose);
    }
}
